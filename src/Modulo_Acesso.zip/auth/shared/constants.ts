export const jwtConstants = {
    secret: 'TesT4nD0$Ch4v3S3cREt4'
};